<?php

interface htmlrenderable { 
	function getValor();
	function html();
}

?>