<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1"> <title>Insert title here</title> </head>
<body>
<h1>AUTENTIFICACION</h1>
<h3><?php $error ?><h3>
<form action='http://localhost/prueba/anexo-10-p32-ejercicio_upd/public/controlusuarios/autentificar' method="post">
<p>USUARIO<input type="text" name="usuario"></p> 
<p>CONTRASENA<input type="password" name="clave"></p> 
<input type="submit" value="Comprobar">
</form> </body>

</html>