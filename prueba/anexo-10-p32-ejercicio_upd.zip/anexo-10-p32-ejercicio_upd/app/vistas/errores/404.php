<?php 
defined("APPPATH") OR die("Access denied");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>PAGINA NO ENCONTRADA</title>
</head>
<body>
	<h2>Lo sentimos, hay un error 404...</h2>

	<a href="http://localhost/prueba/anexo10-p32-ejercicio/public">Volver al inicio</a>
</body>
</html>