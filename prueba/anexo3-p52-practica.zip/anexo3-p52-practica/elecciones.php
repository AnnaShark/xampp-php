


<?php
$nombre_partido["JxSí"]="JUNTS PEL SÍ";
$nombre_partido["C's"]="CIUTADANS-PARTIDO DE LA CIUDADANÍA";
$nombre_partido["PSC"]="PARTIT DELS SOCIALISTES DE CATALUNYA (PSC-PSOE)"; $nombre_partido["CatSíqueesPot"]="CATALUNYA SÍ QUE ES POT";
$nombre_partido["PP"]="PARTIT POPULAR";
$nombre_partido["CUP"]="CANDIDATURA D'UNITAT POPULAR";
$nombre_partido["unio.cat"]="UNIÓ DEMOCRÀTICA DE CATALUNYA";
$nombre_partido["PACMA"]="PARTIT ANIMALISTA CONTRA EL MALTRACTAMENT ANIMAL"; $nombre_partido["RECORTES CERO-ELS VERDS"]="RECORTES CERO-ELS VERDS"; $nombre_partido["GANEMOS"]="GUANYEM CATALUNYA";
$nombre_partido["PIRATA.CAT/XDT"]="PIRATES DE CATALUNYA - PER DECIDIR-HO TOT";


$circunscripciones[]="Barcelona";
$circunscripciones[]="Girona";
$circunscripciones[]="Lleida";
$circunscripciones[]="Tarragona";


$comarcas["Barcelona"][]="Alt Penedès";
$comarcas["Barcelona"][]="Anoia";
$comarcas["Barcelona"][]="Bages";
$comarcas["Barcelona"][]="Garraf";
$comarcas["Girona"][]="Alt Empordà";
$comarcas["Girona"][]="Baix Empordà";
$comarcas["Girona"][]="Cerdanya (G)";
$comarcas["Girona"][]="Selva (G)";
$comarcas["Lleida"][]="Alta Ribagorça";
$comarcas["Lleida"][]="Alt Urgell";
$comarcas["Lleida"][]="Aran";
$comarcas["Lleida"][]="Berguedà (L)";
$comarcas["Tarragona"][]="Tarragona comarca1";
$comarcas["Tarragona"][]="Tarragona comarca2";
$comarcas["Tarragona"][]="Tarragona comarca3";


$ayuntamientos["Alt Penedès"][]="Alt Penedès ayuntamiento1";
$ayuntamientos["Alt Penedès"][]="Alt Penedès ayuntamiento2";
$ayuntamientos["Alt Penedès"][]="Alt Penedès ayuntamiento3";
$ayuntamientos["Anoia"][]="Anoia ayuntamiento1";
$ayuntamientos["Anoia"][]="Anoia ayuntamiento2";
$ayuntamientos["Anoia"][]="Anoia ayuntamiento3";
$ayuntamientos["Bages"][]="Bages ayuntamiento1";
$ayuntamientos["Bages"][]="Bages ayuntamiento2";
$ayuntamientos["Bages"][]="Bages ayuntamiento3";
$ayuntamientos["Garraf"][]="Garraf ayuntamiento1";
$ayuntamientos["Garraf"][]="Garraf ayuntamiento2";
$ayuntamientos["Garraf"][]="Garraf ayuntamiento3";
$ayuntamientos["Alt Empordà"][]="Alt Empordà ayuntamiento1";
$ayuntamientos["Alt Empordà"][]="Alt Empordà ayuntamiento2";
$ayuntamientos["Alt Empordà"][]="Alt Empordà ayuntamiento3";
$ayuntamientos["Alta Ribagorça"][]="Pont de Suert, el";
$ayuntamientos["Alta Ribagorça"][]="Vall de Boí, la";
$ayuntamientos["Alta Ribagorça"][]="Vilaller";
$ayuntamientos["Alt Camp"][]="Aiguamúrcia";
$ayuntamientos["Alt Camp"][]="Alcover";
$ayuntamientos["Alt Camp"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Alió";
$ayuntamientos["Berguedà (L)"][]="Vielha e Mijaran";
$ayuntamientos["Tarragona comarca2"][]="Tarragona comarca2 ayuntamiento1";
$ayuntamientos["Baix Empordà"][]="Baix Empordà ayuntamiento1";
$ayuntamientos["Cerdanya (G)"][]="Cerdanya (G) ayuntamiento1";
$ayuntamientos["Selva (G)"][]="Selva (G) ayuntamiento1";
$ayuntamientos["Alt Urgell"][]="Alt Urgell ayuntamiento1";
$ayuntamientos["Aran"][]="Aran ayuntamiento1";
$ayuntamientos["Tarragona comarca1"][]="Tarragona comarca1 ayuntamiento1";
$ayuntamientos["Tarragona comarca3"][]="Tarragona comarca3 ayuntamiento1";


$votos["Alt Penedès ayuntamiento1"]=array("censo" => 139, "JxSí" => 57, "C's" => 9,"PSC" => 11, "CatSíqueesPot" => 3, "PP" => 5, "CUP" => 18, "unio.cat" => 3, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alt Penedès ayuntamiento2"]=array("censo" => 8828, "JxSí" => 1685, "C's" => 1771,"PSC" => 1275, "CatSíqueesPot" => 938, "PP" => 619, "CUP" => 453, "unio.cat" => 131, "PACMA" => 82, "RECORTES CERO-ELS VERDS" => 51, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alt Penedès ayuntamiento3"]=array("censo" => 484, "JxSí" => 271, "C's" => 18,"PSC" => 14, "CatSíqueesPot" => 10, "PP" => 25, "CUP" => 45, "unio.cat" => 9, "PACMA" => 2, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Anoia ayuntamiento1"]=array("censo" => 139, "JxSí" => 57, "C's" => 9,"PSC" => 11, "CatSíqueesPot" => 3, "PP" => 5, "CUP" => 18, "unio.cat" => 3, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Anoia ayuntamiento2"]=array("censo" => 139, "JxSí" => 57, "C's" => 9,"PSC" => 11, "CatSíqueesPot" => 3, "PP" => 5, "CUP" => 18, "unio.cat" => 3, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Anoia ayuntamiento3"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Bages ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Bages ayuntamiento2"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Bages ayuntamiento3"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Garraf ayuntamiento1"]=array("censo" => 3778, "JxSí" => 1940, "C's" => 252,"PSC" => 161, "CatSíqueesPot" => 104, "PP" => 185, "CUP" => 152, "unio.cat" => 87, "PACMA" => 9, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 3, "PIRATA.CAT/XDT" => 0 );
$votos["Garraf ayuntamiento2"]=array("censo" => 3778, "JxSí" => 1940, "C's" => 252,"PSC" => 161, "CatSíqueesPot" => 104, "PP" => 185, "CUP" => 152, "unio.cat" => 87, "PACMA" => 9, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 3, "PIRATA.CAT/XDT" => 0 );
$votos["Garraf ayuntamiento3"]=array("censo" => 3778, "JxSí" => 1940, "C's" => 252,"PSC" => 161, "CatSíqueesPot" => 104, "PP" => 185, "CUP" => 152, "unio.cat" => 87, "PACMA" => 9, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 3, "PIRATA.CAT/XDT" => 0 );

$votos["Abrera"]=array("censo" => 8828, "JxSí" => 1685, "C's" => 1771,"PSC" => 1275, "CatSíqueesPot" => 938, "PP" => 619, "CUP" => 453, "unio.cat" => 131, "PACMA" => 82, "RECORTES CERO-ELS VERDS" => 51, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Àger"]=array("censo" => 484, "JxSí" => 271, "C's" => 18,"PSC" => 14, "CatSíqueesPot" => 10, "PP" => 25, "CUP" => 45, "unio.cat" => 9, "PACMA" => 2, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Agramunt"]=array("censo" => 3778, "JxSí" => 1940, "C's" => 252,"PSC" => 161, "CatSíqueesPot" => 104, "PP" => 185, "CUP" => 152, "unio.cat" => 87, "PACMA" => 9, "RECORTES CERO-ELS VERDS" => 1, "GANEMOS" => 3, "PIRATA.CAT/XDT" => 0 );
$votos["Aguilar de Segarra"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Baix Empordà ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Selva (G) ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alt Empordà ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alt Empordà ayuntamiento2"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alt Empordà ayuntamiento3"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Cerdanya (G) ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Aran ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Pont de Suert, el"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Vall de Boí, la"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Vilaller"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alt Urgell ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Alió"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Vielha e Mijaran"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Tarragona comarca1 ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Tarragona comarca2 ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );
$votos["Tarragona comarca3 ayuntamiento1"]=array("censo" => 203, "JxSí" => 121, "C's" => 4,"PSC" => 0, "CatSíqueesPot" => 5, "PP" => 4, "CUP" => 18, "unio.cat" => 10, "PACMA" => 0, "RECORTES CERO- ELS VERDS" => 1, "GANEMOS" => 0, "PIRATA.CAT/XDT" => 0 );

?>